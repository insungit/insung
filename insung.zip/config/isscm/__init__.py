from .decorators import login_required
from config import settings
import static